// Smooth scroll for nav links & small reveal observer
document.querySelectorAll('.nav-link').forEach(a=>{
  a.addEventListener('click', e=>{
    e.preventDefault();
    const id = a.getAttribute('href');
    document.querySelector(id).scrollIntoView({behavior:'smooth', block:'start'});
    history.replaceState(null,'',id);
  });
});

// simple reveal on scroll for panels
const io = new IntersectionObserver((entries)=>{
  entries.forEach(en=>{
    if(en.isIntersecting) en.target.classList.add('reveal');
  });
},{threshold:0.12});

document.querySelectorAll('.panel, .hero').forEach(el=> io.observe(el));
