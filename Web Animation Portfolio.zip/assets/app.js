/* Simple SPA-like behavior with smooth scroll + scroll-triggered reveal animations
   Language support: English (en) and Indonesian (id)
   Only public-safe data shown: email and selected public roles.
*/

const i18n = {
  en: {
    title: "Software Engineer",
    subtitle: "Backend & Mobile — Squad Lead",
    summary: "Experienced engineer building scalable web & mobile systems. Currently focused on NestJS & Nx monorepo architecture.",
    about_title: "About",
    about_text: "Squad Lead with 8+ years experience in web, mobile and backend. Skilled in system design, API architecture, and end-to-end delivery.",
    exp_title: "Experience",
    skills_title: "Skills",
    projects_title: "Selected Projects",
    contact_title: "Contact",
    contact_text: "Email: iwongunawan@gmail.com",
    footer: "© Iwon Gunawan — public portfolio (redacted personal phone)"
  },
  id: {
    title: "Software Engineer",
    subtitle: "Backend & Mobile — Squad Lead",
    summary: "Engineer berpengalaman membangun sistem web & mobile yang scalable. Fokus pada arsitektur NestJS & Nx.",
    about_title: "Tentang",
    about_text: "Squad Lead dengan pengalaman 8+ tahun di web, mobile, dan backend. Terampil dalam desain sistem, arsitektur API, dan delivery end-to-end.",
    exp_title: "Pengalaman",
    skills_title: "Keahlian",
    projects_title: "Proyek Terpilih",
    contact_title: "Kontak",
    contact_text: "Email: iwongunawan@gmail.com",
    footer: "© Iwon Gunawan — portofolio publik (nomor telepon disensor)"
  }
};

const PUBLIC_DATA = {
  // sanitized & public-friendly subset taken from uploaded CVs
  roles: [
    {company: "PT. Krakatau Karya Abadi (SuperApp)", title: "Software Engineer — Squad Lead", period: "Aug 2022 - Current"},
    {company: "PT. Phintraco Technology", title: "Android Developer", period: "Dec 2019 - Jul 2022"},
    {company: "PT. Kosada Group Indonesia", title: "Mobile & Backend Developer", period: "May 2017 - Nov 2019"}
  ],
  skills: ["TypeScript","JavaScript","NestJS","Nx Monorepo","REST API","MySQL","MongoDB","Typesense","Redis","Git"],
  projects: [
    {title:"Mitra / SalesApp / SuperApp", desc:"Integrated commerce ecosystem — internal management, field sales, and customer app."},
    {title:"KeyBCA Soft Token", desc:"Android mobile token for banking transaction authentication."},
    {title:"Barantum CRM", desc:"Mobile & Web CRM platform with GPS tracking and offline mode."}
  ]
};

function populateContent(lang='en'){
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(i18n[lang] && i18n[lang][key]) el.textContent = i18n[lang][key];
  });

  // experience
  const expList = document.getElementById('exp-list');
  expList.innerHTML = '';
  PUBLIC_DATA.roles.forEach(r=>{
    const li = document.createElement('li');
    li.innerHTML = `<strong>${r.title}</strong> — <span class="muted">${r.company}</span><br><small class="muted">${r.period}</small>`;
    expList.appendChild(li);
  });

  // skills
  const skillsList = document.getElementById('skills-list');
  skillsList.innerHTML = '';
  PUBLIC_DATA.skills.forEach(s=>{
    const d = document.createElement('div');
    d.className = 'chip';
    d.textContent = s;
    skillsList.appendChild(d);
  });

  // projects
  const projectsList = document.getElementById('projects-list');
  projectsList.innerHTML = '';
  PUBLIC_DATA.projects.forEach(p=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<h4>${p.title}</h4><p class="muted">${p.desc}</p>`;
    projectsList.appendChild(card);
  });

  // trigger observer to animate freshly added items
  setupObserver();
}

let currentLang = 'en';
document.getElementById('lang-toggle').addEventListener('click', ()=>{
  currentLang = currentLang === 'en' ? 'id' : 'en';
  populateContent(currentLang);
});

// nav links smooth behavior + set active
document.querySelectorAll('.nav-link').forEach(a=>{
  a.addEventListener('click', (e)=>{
    e.preventDefault();
    const id = a.getAttribute('data-target');
    document.getElementById(id).scrollIntoView({behavior:'smooth', block:'start'});
    // update URL hash without page reload
    history.replaceState(null,'', '#' + id);
  });
});

// IntersectionObserver for reveal animations
let observer = null;
function setupObserver(){
  if(observer) observer.disconnect();
  observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('in-view');
      }
    });
  }, {threshold: 0.15});
  document.querySelectorAll('.list li, .chip, .card, .hero-text, .hero-image').forEach(el=>{
    observer.observe(el);
  });
}

// initial render
populateContent(currentLang);

// small: highlight nav when section in view
const secObserver = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    const id = e.target.id;
    const link = document.querySelector('.nav-link[data-target="'+id+'"]');
    if(e.isIntersecting){ link && link.classList.add('active'); }
    else{ link && link.classList.remove('active'); }
  });
},{threshold:0.6});

document.querySelectorAll('section').forEach(s=>{
  secObserver.observe(s);
});
